# Smart Expense Tracker

A responsive Flask + SQLite mini project for recording personal income and expenses.

## Features
- Dashboard cards for total income, total expenses and available balance
- Add, edit and delete transactions
- Category and date validation
- Search/filter transactions
- Expense breakdown chart
- Monthly report and category totals
- SQLite persistence

## Run on Windows
1. Open this folder in VS Code.
2. In the VS Code terminal run:
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
3. Open http://127.0.0.1:5000 in your browser.
4. Keep the terminal running while using the site.

The database is created automatically at `instance/expenses.db`.
Do not delete this file if you want to keep saved transactions.

## Notes
This is a student mini-project starter. It is intended for local demonstration, not financial or production use. Change `app.secret_key` before any public deployment.
